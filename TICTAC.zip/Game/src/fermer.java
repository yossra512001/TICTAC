import java.awt.*;
import java.awt.event.*;
class fermer extends WindowAdapter
{
public void windowClosing (WindowEvent e )
{
System.exit(1);
}
}